-- Run this entire file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 160),
  description text,
  category text,
  price_cents integer not null check (price_cents >= 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  customer_email text not null,
  notes text,
  items jsonb not null,
  total_cents integer not null check (total_cents >= 0),
  status text not null default 'pending_transfer'
    check (status in ('pending_transfer','paid','processing','shipped','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

-- Security-definer helper avoids RLS recursion when policies check admin membership.
create or replace function public.is_store_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(select 1 from public.admin_users a where a.user_id = auth.uid());
$$;
revoke all on function public.is_store_admin() from public;
grant execute on function public.is_store_admin() to anon, authenticated;

drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products" on public.products for select
using (active = true or public.is_store_admin());

drop policy if exists "Admins can insert products" on public.products;
create policy "Admins can insert products" on public.products for insert
with check (public.is_store_admin());

drop policy if exists "Admins can update products" on public.products;
create policy "Admins can update products" on public.products for update
using (public.is_store_admin()) with check (public.is_store_admin());

drop policy if exists "Admins can read orders" on public.orders;
create policy "Admins can read orders" on public.orders for select
using (public.is_store_admin());

drop policy if exists "Admins can update orders" on public.orders;
create policy "Admins can update orders" on public.orders for update
using (public.is_store_admin()) with check (public.is_store_admin());

-- Anonymous customers can submit orders only through this function. It re-reads prices
-- from the database and decrements inventory atomically to prevent client-side total tampering.
create or replace function public.create_bank_transfer_order(
  p_customer_name text,
  p_customer_email text,
  p_notes text,
  p_items jsonb
) returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order_id uuid := gen_random_uuid();
  v_item jsonb;
  v_product public.products%rowtype;
  v_qty integer;
  v_total bigint := 0;
  v_saved_items jsonb := '[]'::jsonb;
begin
  if char_length(trim(coalesce(p_customer_name,''))) < 2 or char_length(trim(coalesce(p_customer_name,''))) > 160 then
    raise exception 'Enter a valid customer name';
  end if;
  if trim(coalesce(p_customer_email,'')) !~* '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$' then
    raise exception 'Enter a valid email address';
  end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) < 1 or jsonb_array_length(p_items) > 30 then
    raise exception 'Your order must contain between 1 and 30 line items';
  end if;

  for v_item in select value from jsonb_array_elements(p_items)
  loop
    if (v_item->>'product_id') is null or (v_item->>'quantity') !~ '^[0-9]+$' then
      raise exception 'Invalid order item';
    end if;
    v_qty := (v_item->>'quantity')::integer;
    if v_qty < 1 or v_qty > 1000 then raise exception 'Invalid quantity'; end if;
    select * into v_product from public.products
      where id = (v_item->>'product_id')::uuid and active = true
      for update;
    if not found then raise exception 'A selected product is unavailable'; end if;
    if v_product.stock_quantity < v_qty then raise exception 'Insufficient stock for %', v_product.name; end if;
    v_total := v_total + (v_product.price_cents::bigint * v_qty);
    if v_total > 2000000000 then raise exception 'Order total exceeds the allowed limit'; end if;
    v_saved_items := v_saved_items || jsonb_build_array(jsonb_build_object(
      'product_id',v_product.id,'name',v_product.name,'quantity',v_qty,'unit_price_cents',v_product.price_cents
    ));
    update public.products set stock_quantity = stock_quantity - v_qty, updated_at = now() where id = v_product.id;
  end loop;

  insert into public.orders(id,customer_name,customer_email,notes,items,total_cents,status)
  values(v_order_id,trim(p_customer_name),trim(p_customer_email),left(coalesce(p_notes,''),2000),v_saved_items,v_total::integer,'pending_transfer');
  return v_order_id;
end;
$$;

revoke all on function public.create_bank_transfer_order(text,text,text,jsonb) from public;
grant execute on function public.create_bank_transfer_order(text,text,text,jsonb) to anon, authenticated;

-- Product image storage bucket; admin-only uploads and public image reads.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('product-images','product-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 5242880, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "Public can view product images" on storage.objects;
create policy "Public can view product images" on storage.objects for select using (bucket_id = 'product-images');

drop policy if exists "Admins can upload product images" on storage.objects;
create policy "Admins can upload product images" on storage.objects for insert to authenticated
with check (bucket_id = 'product-images' and public.is_store_admin());

drop policy if exists "Admins can update product images" on storage.objects;
create policy "Admins can update product images" on storage.objects for update to authenticated
using (bucket_id = 'product-images' and public.is_store_admin())
with check (bucket_id = 'product-images' and public.is_store_admin());

-- Do not grant browser clients direct insert/delete access to orders or admin_users.
