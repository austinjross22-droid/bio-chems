import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Bio Chems | Laboratory Supplies",
  description: "Laboratory equipment and general research supplies for eligible professional and educational environments."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
