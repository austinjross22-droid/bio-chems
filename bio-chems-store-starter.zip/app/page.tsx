 "use client";

import { useEffect, useState } from "react";
import { getSupabase } from "@/lib/supabase";

type Product = { id:string; name:string; description:string|null; price_cents:number; image_url:string|null; stock_quantity:number; category:string|null };

function money(cents:number) { return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(cents/100); }

export default function Home() {
  const [products,setProducts] = useState<Product[]>([]);
  const [cart,setCart] = useState<Record<string,number>>({});
  const [loading,setLoading] = useState(true);
  const [message,setMessage] = useState("");
  const [customer,setCustomer] = useState({name:"",email:"",notes:""});
  const [busy,setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    try {
      getSupabase().from("products").select("id,name,description,price_cents,image_url,stock_quantity,category")
        .eq("active",true).order("created_at",{ascending:false})
        .then(({data,error}) => { if(!alive)return; if(error)setMessage("Products could not load yet. Finish the setup steps in README.md."); else setProducts((data||[]) as Product[]); setLoading(false); });
    } catch { setMessage("Store setup required: configure Supabase using README.md."); setLoading(false); }
    return () => { alive=false; };
  },[]);

  const count = Object.values(cart).reduce((a,b)=>a+b,0);
  const total = products.reduce((sum,p)=>sum+(cart[p.id]||0)*p.price_cents,0);

  async function placeOrder(e:React.FormEvent) {
    e.preventDefault(); setMessage("");
    if(!count) { setMessage("Add at least one item to your order."); return; }
    setBusy(true);
    try {
      const supabase = getSupabase();
      const items = products.filter(p => (cart[p.id]||0)>0).map(p=>({product_id:p.id,quantity:cart[p.id]}));
      const {data,error} = await supabase.rpc("create_bank_transfer_order", {
        p_customer_name:customer.name, p_customer_email:customer.email,
        p_notes:customer.notes, p_items:items
      });
      if(error) throw error;
      setMessage(`Order request ${String(data).slice(0,8)} received. Follow the bank-transfer instructions sent by the store before your order is processed.`);
      setCart({}); setCustomer({name:"",email:"",notes:""});
    } catch(err) {
      setMessage(err instanceof Error ? err.message : "Order could not be submitted. Please contact the store.");
    } finally { setBusy(false); }
  }

  return <>
    <header className="topbar"><div className="shell nav">
      <a className="brand" href="#"><span className="brand-mark">⚗</span><span>BIO CHEMS<br/><span className="small">LABORATORY SUPPLIES</span></span></a>
      <nav className="navlinks"><a href="#catalog">Catalog</a><a href="#ordering">Ordering</a><a href="/admin">Admin</a></nav>
    </div></header>
    <main className="shell">
      <section className="hero">
        <div><div className="eyebrow">Tools for careful work</div><h1>Precision for the laboratory.</h1>
          <p>Explore general laboratory equipment, glassware, and accessories for eligible professional and educational environments.</p>
          <a className="btn" href="#catalog">Browse supplies <span aria-hidden="true">↗</span></a>
        </div>
        <div className="hero-card"><div className="orbit">⚗</div><div><div className="eyebrow">BIO CHEMS</div><h2>Reliable essentials.<br/>Clear ordering.</h2><p className="small">Thoughtfully organized supplies for your workspace.</p></div></div>
      </section>

      <section className="section" id="catalog">
        <div className="section-head"><div><div className="eyebrow">Catalog</div><h2>Laboratory essentials</h2><p>Product availability and pricing are shown below.</p></div><span className="badge">{count} item(s) selected</span></div>
        {message && <div className="notice" style={{marginBottom:16}}>{message}</div>}
        {loading ? <p>Loading catalog…</p> : products.length===0 ? <div className="panel"><h3>Catalog coming soon</h3><p>Add eligible products from the admin dashboard after completing the setup instructions.</p></div> :
          <div className="grid">{products.map(p=><article className="card" key={p.id}>
            <div className="product-image">{p.image_url ? <img src={p.image_url} alt={p.name}/> : "⚗"}</div>
            <div className="card-body"><span className="badge">{p.category||"Laboratory supply"}</span><h3 style={{marginTop:10}}>{p.name}</h3><p>{p.description||"General laboratory supply."}</p>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:10}}><span className="price">{money(p.price_cents)}</span><span className="small">{p.stock_quantity>0 ? `${p.stock_quantity} available` : "Out of stock"}</span></div>
              <div className="actions" style={{marginTop:14}}><button className="btn" disabled={p.stock_quantity<1 || (cart[p.id]||0)>=p.stock_quantity} onClick={()=>setCart(c=>({...c,[p.id]:(c[p.id]||0)+1}))}>Add to order</button>{(cart[p.id]||0)>0&&<button className="btn secondary" onClick={()=>setCart(c=>({...c,[p.id]:Math.max(0,(c[p.id]||0)-1)}))}>− {cart[p.id]} +</button>}</div>
            </div></article>)}</div>}
      </section>

      <section className="section" id="ordering"><div className="two-col">
        <div className="panel"><div className="eyebrow">Order summary</div><h2>Your order</h2>
          {products.filter(p=>(cart[p.id]||0)>0).map(p=><div key={p.id} style={{display:"flex",justifyContent:"space-between",gap:12,padding:"10px 0",borderBottom:"1px solid var(--line)"}}><span>{p.name} × {cart[p.id]}</span><strong>{money(p.price_cents*(cart[p.id]||0))}</strong></div>)}
          <div style={{display:"flex",justifyContent:"space-between",padding:"18px 0"}}><strong>Estimated total</strong><strong className="price">{money(total)}</strong></div>
          <p className="small">Shipping, taxes, and any applicable fees will be confirmed by the store before fulfillment.</p>
          <div className="notice">Bank transfer is handled manually. Your order is not paid or confirmed until the store verifies receipt of funds. Do not send money until you receive verified payment instructions.</div>
        </div>
        <div className="panel"><div className="eyebrow">Checkout</div><h2>Request an order</h2>
          <form className="form" onSubmit={placeOrder}>
            <div className="field"><label htmlFor="name">Full name</label><input id="name" required value={customer.name} onChange={e=>setCustomer({...customer,name:e.target.value})}/></div>
            <div className="field"><label htmlFor="email">Email address</label><input id="email" type="email" required value={customer.email} onChange={e=>setCustomer({...customer,email:e.target.value})}/></div>
            <div className="field"><label htmlFor="notes">Order notes (optional)</label><textarea id="notes" value={customer.notes} onChange={e=>setCustomer({...customer,notes:e.target.value})} placeholder="Shipping questions or other details"/></div>
            <button className="btn" disabled={busy||count===0}>{busy?"Submitting…": "Submit order request"}</button>
            <p className="small">Submitting an order request does not mean payment has been received or an order has been approved.</p>
          </form>
        </div>
      </div></section>
    </main>
    <footer className="footer"><div className="shell"><strong>BIO CHEMS</strong><p>Laboratory equipment and general supplies. Products must be used in accordance with their labeling and applicable laws.</p><span>© {new Date().getFullYear()} Bio Chems · <a href="mailto:orders@example.com">Contact</a> · <a href="/admin">Store admin</a></span></div></footer>
  </>;
}
