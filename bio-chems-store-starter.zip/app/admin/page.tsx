 "use client";

import { useEffect, useState } from "react";
import { getSupabase } from "@/lib/supabase";

type Product = {id:string;name:string;description:string|null;category:string|null;price_cents:number;stock_quantity:number;image_url:string|null;active:boolean};
type Order = {id:string;customer_name:string;customer_email:string;total_cents:number;status:string;created_at:string;notes:string|null};

const blank = {name:"",description:"",category:"Laboratory supplies",price:"",stock:"0",active:true};
const money = (n:number) => new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(n/100);

export default function Admin() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [session,setSession]=useState<any>(null); const [products,setProducts]=useState<Product[]>([]);
  const [orders,setOrders]=useState<Order[]>([]); const [form,setForm]=useState(blank);
  const [editing,setEditing]=useState<string|null>(null); const [photo,setPhoto]=useState<File|null>(null);
  const [message,setMessage]=useState(""); const [tab,setTab]=useState<"products"|"orders">("products");
  const [loading,setLoading]=useState(false);

  async function refresh() {
    const s=getSupabase();
    const [{data:p,error:pe},{data:o,error:oe}] = await Promise.all([
      s.from("products").select("*").order("created_at",{ascending:false}),
      s.from("orders").select("*").order("created_at",{ascending:false})
    ]);
    if(pe) setMessage(pe.message); else setProducts((p||[]) as Product[]);
    if(oe) setMessage(oe.message); else setOrders((o||[]) as Order[]);
  }
  useEffect(()=>{ try {const s=getSupabase(); s.auth.getSession().then(({data})=>{setSession(data.session);if(data.session)refresh()}); const {data:{subscription}}=s.auth.onAuthStateChange((_e,ses)=>{setSession(ses);if(ses)refresh()}); return ()=>subscription.unsubscribe();} catch(e) {setMessage("Configure Supabase first, following README.md.");} },[]);

  async function signIn(e:React.FormEvent) {e.preventDefault();setMessage("");const {data,error}=await getSupabase().auth.signInWithPassword({email,password});if(error)setMessage(error.message);else{setSession(data.session);await refresh();}}
  async function signOut(){await getSupabase().auth.signOut();setSession(null);setProducts([]);setOrders([]);}
  function startEdit(p:Product){setEditing(p.id);setForm({name:p.name,description:p.description||"",category:p.category||"",price:(p.price_cents/100).toFixed(2),stock:String(p.stock_quantity),active:p.active});setPhoto(null);window.scrollTo({top:0,behavior:"smooth"});}
  function reset(){setEditing(null);setForm(blank);setPhoto(null);}
  async function saveProduct(e:React.FormEvent){
    e.preventDefault();setLoading(true);setMessage("");
    try {
      const s=getSupabase(); let image_url:string|null=null;
      if(photo){const ext=photo.name.split(".").pop()?.toLowerCase()||"jpg";const path=`${crypto.randomUUID()}.${ext}`;const {error:upErr}=await s.storage.from("product-images").upload(path,photo,{upsert:false,contentType:photo.type});if(upErr)throw upErr;image_url=s.storage.from("product-images").getPublicUrl(path).data.publicUrl;}
      const record:any={name:form.name.trim(),description:form.description.trim()||null,category:form.category.trim()||null,price_cents:Math.round(Number(form.price)*100),stock_quantity:Math.max(0,Math.floor(Number(form.stock))),active:form.active};
      if(image_url)record.image_url=image_url;
      if(editing){const {error}=await s.from("products").update(record).eq("id",editing);if(error)throw error;}
      else {const {error}=await s.from("products").insert(record);if(error)throw error;}
      setMessage(editing?"Product updated.":"Product added.");reset();await refresh();
    }catch(e){setMessage(e instanceof Error?e.message:"Could not save product.");}finally{setLoading(false);}
  }
  async function updateStatus(id:string,status:string){const {error}=await getSupabase().from("orders").update({status}).eq("id",id);setMessage(error?error.message:"Order status updated.");await refresh();}
  async function toggleActive(p:Product){const {error}=await getSupabase().from("products").update({active:!p.active}).eq("id",p.id);setMessage(error?error.message:"Product visibility updated.");await refresh();}

  if(!session)return <main className="shell" style={{padding:"70px 0",maxWidth:520}}><a className="brand" href="/"><span className="brand-mark">⚗</span>BIO CHEMS ADMIN</a><div className="panel" style={{marginTop:24}}><h1 style={{fontSize:34}}>Store admin</h1><p>Sign in with the administrator account you created in Supabase. Public account registration is intentionally disabled.</p>{message&&<div className="notice" style={{marginBottom:14}}>{message}</div>}<form className="form" onSubmit={signIn}><div className="field"><label>Email</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></div><div className="field"><label>Password</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)}/></div><button className="btn">Sign in</button></form><p className="small"><a href="/">← Back to store</a></p></div></main>;

  return <main className="shell" style={{padding:"36px 0 70px"}}><div className="section-head"><div><div className="eyebrow">Control panel</div><h1 style={{fontSize:38}}>Store admin</h1><p>Manage eligible products and incoming bank-transfer order requests.</p></div><button className="btn secondary" onClick={signOut}>Sign out</button></div>
    {message&&<div className="notice" style={{marginBottom:16}}>{message}</div>}
    <div className="actions" style={{marginBottom:22}}><button className={`btn ${tab==="products"?"":"secondary"}`} onClick={()=>setTab("products")}>Products ({products.length})</button><button className={`btn ${tab==="orders"?"":"secondary"}`} onClick={()=>setTab("orders")}>Orders ({orders.length})</button><a className="btn secondary" href="/">View storefront ↗</a></div>
    {tab==="products"? <div className="two-col" style={{alignItems:"start"}}>
      <section className="panel"><h2>{editing?"Edit product":"Add a product"}</h2><form className="form" onSubmit={saveProduct}>
        <div className="field"><label>Product name</label><input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div>
        <div className="field"><label>Description</label><textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></div>
        <div className="two-col"><div className="field"><label>Category</label><input value={form.category} onChange={e=>setForm({...form,category:e.target.value})}/></div><div className="field"><label>Price (USD)</label><input required type="number" min="0" step=".01" value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/></div></div>
        <div className="field"><label>Stock quantity</label><input required type="number" min="0" step="1" value={form.stock} onChange={e=>setForm({...form,stock:e.target.value})}/></div>
        <div className="field"><label>Product photo</label><input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>setPhoto(e.target.files?.[0]||null)}/><span className="small">Use a JPG, PNG, or WebP image. Uploads are stored in Supabase.</span></div>
        <label style={{display:"flex",gap:8,alignItems:"center"}}><input type="checkbox" style={{width:"auto"}} checked={form.active} onChange={e=>setForm({...form,active:e.target.checked})}/> Visible in public catalog</label>
        <div className="actions"><button className="btn" disabled={loading}>{loading?"Saving…":editing?"Save changes":"Add product"}</button>{editing&&<button type="button" className="btn secondary" onClick={reset}>Cancel</button>}</div>
      </form></section>
      <section><h2>Current products</h2><div style={{display:"grid",gap:10}}>{products.map(p=><div className="panel" key={p.id}><div style={{display:"flex",justifyContent:"space-between",gap:10}}><div><strong>{p.name}</strong><p style={{margin:"5px 0"}}>{money(p.price_cents)} · Stock: {p.stock_quantity}</p><span className="badge">{p.active?"Visible":"Hidden"}</span></div><div className="actions"><button className="btn secondary" onClick={()=>startEdit(p)}>Edit</button><button className="btn secondary" onClick={()=>toggleActive(p)}>{p.active?"Hide":"Show"}</button></div></div></div>)}{products.length===0&&<p>No products yet. Add your first item.</p>}</div></section>
    </div> : <section><h2>Incoming orders</h2><p>Verify bank transfers using your bank directly before marking an order paid. Never rely on screenshots or customer claims alone.</p><div className="table-wrap"><table><thead><tr><th>Date</th><th>Customer</th><th>Total</th><th>Status</th><th>Update</th></tr></thead><tbody>{orders.map(o=><tr key={o.id}><td>{new Date(o.created_at).toLocaleDateString()}</td><td>{o.customer_name}<br/><span className="small">{o.customer_email}</span><br/><span className="small">{o.notes||""}</span></td><td>{money(o.total_cents)}</td><td><span className="badge">{o.status}</span></td><td><select value={o.status} onChange={e=>updateStatus(o.id,e.target.value)}><option value="pending_transfer">Pending transfer</option><option value="paid">Paid</option><option value="processing">Processing</option><option value="shipped">Shipped</option><option value="cancelled">Cancelled</option></select></td></tr>)}{orders.length===0&&<tr><td colSpan={5}>No orders yet.</td></tr>}</tbody></table></div></section>}
  </main>;
}
