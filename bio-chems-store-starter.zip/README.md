# Bio Chems — custom ecommerce starter

A dark, responsive Next.js storefront with:
- Public catalog for eligible, lawful general laboratory equipment/supplies
- Admin login using Supabase Auth
- Add/edit products, price, stock, visibility, and photo upload
- Customer order requests using bank transfer
- Admin order list and manual status updates
- Database-side order totals and inventory decrement

This is a **deployable starter project**, not a store already hosted online. You must connect your own services and test before launch.

## Important product / compliance boundary
This starter is for ordinary, lawful laboratory equipment and general supplies. A “research use only” label does not by itself make a drug or controlled/restricted substance lawful to sell. Do not list peptides, anabolic steroids, prescription drugs, or other restricted items without qualified legal review and all required authorizations. Check the rules for every destination where you sell or ship.

## 1. Create Supabase backend
1. Create a project at https://supabase.com/.
2. In Project Settings > API, copy the Project URL and anon/public key.
3. Open SQL Editor and run all of `supabase/schema.sql`.
4. In Authentication > Users, create your own admin user with email and a strong password.
5. Copy that user's UUID.
6. In SQL Editor run, replacing the UUID:
   ```sql
   insert into public.admin_users(user_id)
   values ('PASTE-YOUR-AUTH-USER-UUID-HERE');
   ```
   Only users explicitly added to `admin_users` can manage products/orders. Never add public visitors as admins.
7. Under Authentication settings, disable public sign-ups if not needed.

## 2. Run locally
Install Node.js 20+ (https://nodejs.org/) and then in this folder run:
```bash
npm install
cp .env.example .env.local
```
Edit `.env.local` with your Supabase URL and anon key. Set the store email and a short bank-transfer instruction message. Do **not** put bank account credentials or Supabase service-role keys in `NEXT_PUBLIC_*` variables.
```bash
npm run dev
```
Open http://localhost:3000. Sign into `/admin` using the admin user you created.

## 3. Bank transfer workflow
- Customer submits an order request; the database verifies current prices and stock, records the order as `pending_transfer`, and decrements stock.
- This starter does not automatically send email or show bank details. Contact the customer through a verified channel with your business's payment instructions.
- Check the bank account directly to verify cleared funds, then change order status in admin.
- Before production, add a transactional email provider and order confirmation emails. Consider an order-expiration/restock process for unpaid orders; the starter reserves stock immediately.
- Add tax/shipping calculation, privacy policy, terms, refund policy, business contact details, and applicable compliance checks before launch.

## 4. Publish the site
Recommended: Vercel + Supabase.
1. Push this folder to a private GitHub repository.
2. Import the repository at https://vercel.com/.
3. Add the same environment variables from `.env.local` in Vercel Project Settings > Environment Variables. Do not commit `.env.local`.
4. Deploy and test the preview.
5. In Vercel Project Settings > Domains, add a domain you own and follow the DNS instructions from your registrar.
6. Configure the domain's DNS exactly as Vercel instructs, then wait for verification and TLS certificate setup.
7. Test mobile layout, catalog, admin login, image upload, order creation, stock decrement, and admin status changes before announcing the site.

## 5. Before taking real orders
- Confirm product legality, labeling, shipping, and any permits with a qualified professional.
- Confirm your bank and payment/merchant providers permit the exact business and product mix.
- Bank transfer is a manual workflow, not a card processor. Do not claim an order is paid until funds are verified.
- Add rate limiting / bot protection, monitoring, backups, customer privacy controls, and email notifications before meaningful production traffic.
- Use a business bank account where appropriate. Do not publish account details in the source code.
- This starter does not provide a complete tax engine, automated email, shipping labels, refunds, or chargeback tools.

## Files
- `app/page.tsx`: storefront and order form
- `app/admin/page.tsx`: product/order dashboard
- `supabase/schema.sql`: database, access policies, image bucket, order function
- `app/globals.css`: dark premium design
